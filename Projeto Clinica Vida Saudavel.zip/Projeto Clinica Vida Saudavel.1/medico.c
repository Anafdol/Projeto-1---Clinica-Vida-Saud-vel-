#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "medico.h"

typedef struct NoC {
    Medico dados;
    struct NoC* prox;
} NoC;

struct Escala {
    NoC* atual;      
    int tamanho;
};

Escala* medico_criar_escala() {
    Escala* e = (Escala*) malloc(sizeof(Escala));
    if (e == NULL) return NULL;
    e->atual = NULL;
    e->tamanho = 0;
    return e;
}


static NoC* anterior_ao_atual(Escala* e) {
    NoC* p = e->atual;
    while (p->prox != e->atual) p = p->prox;
    return p;
}

void medico_inserir(Escala* e, int id, char* nome, char* especialidade) {
    if (e == NULL) return;
    NoC* novo = (NoC*) malloc(sizeof(NoC));
    if (novo == NULL) return;
    novo->dados.id = id;
    strncpy(novo->dados.nome, nome, sizeof(novo->dados.nome) - 1);
    novo->dados.nome[sizeof(novo->dados.nome) - 1] = '\0';
    strncpy(novo->dados.especialidade, especialidade, sizeof(novo->dados.especialidade) - 1);
    novo->dados.especialidade[sizeof(novo->dados.especialidade) - 1] = '\0';

    if (e->atual == NULL) {               /* caso 1: escala vazia */
        novo->prox = novo;                /* aponta para si mesmo */
        e->atual = novo;
    } else {                              /* caso 2: entra no fim da rodada */
        NoC* ant = anterior_ao_atual(e);
        ant->prox = novo;
        novo->prox = e->atual;
    }
    e->tamanho++;
}

void medico_listar(Escala* e) {
    if (e == NULL || e->atual == NULL) {
        printf("Escala medica vazia.\n");
        return;
    }
    printf("--- Escala medica (a partir do plantonista da vez) ---\n");
    NoC* p = e->atual;
    for (int i = 0; i < e->tamanho; i++) {
        printf("%s ID %d - %s (%s)\n", (i == 0) ? "-> " : "   ",
               p->dados.id, p->dados.nome, p->dados.especialidade);
        p = p->prox;
    }
}

void medico_avancar(Escala* e) {
    if (e == NULL || e->atual == NULL) return;
    e->atual = e->atual->prox;
}

Medico* medico_get_atual(Escala* e) {
    if (e == NULL || e->atual == NULL) return NULL;
    return &e->atual->dados;
}

void medico_remover_atual(Escala* e) {
    if (e == NULL || e->atual == NULL) return;      

    if (e->tamanho == 1) {                       
        free(e->atual);
        e->atual = NULL;
    } else {                                       
        NoC* ant = anterior_ao_atual(e);
        NoC* alvo = e->atual;
        ant->prox = alvo->prox;
        e->atual = alvo->prox;                     
        free(alvo);
    }
    e->tamanho--;
}

void medico_destruir_escala(Escala** e) {
    if (e == NULL || *e == NULL) return;
    while ((*e)->atual != NULL) medico_remover_atual(*e);
    free(*e);
    *e = NULL;
}

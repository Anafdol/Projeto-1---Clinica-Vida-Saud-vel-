#ifndef PACIENTE_H
#define PACIENTE_H

typedef struct {
    int id;
    char nome[50];
} Paciente;

typedef struct NoS {
    Paciente dados;
    struct NoS* prox;
} NoS;

NoS*      paciente_criar_cadastro();                        
int       paciente_inserir(NoS* lista, int id, char* nome); 
Paciente* paciente_buscar(NoS* lista, int id);              
int       paciente_remover(NoS* lista, int id);             
void      paciente_listar(NoS* lista);
void      paciente_destruir_cadastro(NoS** lista);

#endif

#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

typedef struct NoP {
    void* dado;
    struct NoP* prox;
} NoP;

struct Pilha {
    NoP* topo;
    int tamanho;
};

Pilha* pilha_criar() {
    Pilha* p = (Pilha*) malloc(sizeof(Pilha));
    if (p == NULL) return NULL;
    p->topo = NULL;
    p->tamanho = 0;
    return p;
}

void pilha_adicionar(Pilha** p, void* dado) {
    if (p == NULL || *p == NULL) return;
    NoP* novo = (NoP*) malloc(sizeof(NoP));
    if (novo == NULL) return;
    novo->dado = dado;
    novo->prox = (*p)->topo;     
    (*p)->topo = novo;        
    (*p)->tamanho++;
}

void* pilha_topo(Pilha* p) {
    if (p == NULL || p->topo == NULL) return NULL;
    return p->topo->dado;
}

void pilha_remover(Pilha** p) {
    if (p == NULL || *p == NULL || (*p)->topo == NULL) return;
    NoP* aux = (*p)->topo;
    (*p)->topo = aux->prox;
    free(aux);                   
    (*p)->tamanho--;
}

int pilha_tamanho(Pilha* p) {
    return (p == NULL) ? 0 : p->tamanho;
}

int pilha_existe(Pilha* p, int (*pred)(void*, void*), void* ctx) {
    if (p == NULL) return 0;
    for (NoP* n = p->topo; n != NULL; n = n->prox)
        if (pred(n->dado, ctx)) return 1;
    return 0;
}

void pilha_listar(Pilha* p, void (*imprimir)(void*)) {
    if (p == NULL || p->topo == NULL) {
        printf("O historico de atendimentos esta vazio.\n");
        return;
    }
    printf("--- Historico de Atendimentos (Pilha LIFO - Topo e o mais recente) ---\n");
    int pos = 1;
    for (NoP* n = p->topo; n != NULL; n = n->prox) {
        printf("%s ", (pos == 1) ? "[TOPO]" : "      ");
        imprimir(n->dado);
        pos++;
    }
}

void pilha_destruir(Pilha** p) {
    if (p == NULL || *p == NULL) return;
    while ((*p)->topo != NULL) pilha_remover(p);
    free(*p);
    *p = NULL;
}

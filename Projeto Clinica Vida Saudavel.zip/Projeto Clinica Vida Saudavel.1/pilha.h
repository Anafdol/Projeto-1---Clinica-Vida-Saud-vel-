#ifndef PILHA_H
#define PILHA_H

typedef struct Pilha Pilha;

Pilha* pilha_criar();
void   pilha_adicionar(Pilha** p, void* dado);   
void*  pilha_topo(Pilha* p);                     
void   pilha_remover(Pilha** p);               
int    pilha_tamanho(Pilha* p);
int    pilha_existe(Pilha* p, int (*pred)(void*, void*), void* ctx);
void   pilha_listar(Pilha* p, void (*imprimir)(void*));
void   pilha_destruir(Pilha** p);                
#endif

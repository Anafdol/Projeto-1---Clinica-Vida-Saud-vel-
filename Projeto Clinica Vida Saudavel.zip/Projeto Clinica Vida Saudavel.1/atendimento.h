#ifndef ATENDIMENTO_H
#define ATENDIMENTO_H

#include "paciente.h"
#include "medico.h"

typedef struct {
    Paciente* paciente;   
    Medico    medico;    
} Atendimento;

#endif

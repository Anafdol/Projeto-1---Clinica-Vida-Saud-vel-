#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

typedef struct NoF {
    void* dado;
    struct NoF* prox;
} NoF;

struct Fila {
    NoF* inicio;
    NoF* fim;
    int tamanho;
};

Fila* fila_criar() {
    Fila* f = (Fila*) malloc(sizeof(Fila));
    if (f == NULL) return NULL;
    f->inicio = NULL;
    f->fim = NULL;
    f->tamanho = 0;
    return f;
}

void fila_adicionar(Fila** f, void* dado) {
    if (f == NULL || *f == NULL) return;
    NoF* novo = (NoF*) malloc(sizeof(NoF));
    if (novo == NULL) return;
    novo->dado = dado;
    novo->prox = NULL;
    if ((*f)->fim == NULL) {           
        (*f)->inicio = novo;
    } else {
        (*f)->fim->prox = novo;
    }
    (*f)->fim = novo;
    (*f)->tamanho++;
}

void* fila_topo(Fila* f) {
    if (f == NULL || f->inicio == NULL) return NULL;
    return f->inicio->dado;
}

void fila_remover(Fila** f) {
    if (f == NULL || *f == NULL || (*f)->inicio == NULL) return;
    NoF* aux = (*f)->inicio;
    (*f)->inicio = aux->prox;
    if ((*f)->inicio == NULL) (*f)->fim = NULL;  
    free(aux);
    (*f)->tamanho--;
}

int fila_tamanho(Fila* f) {
    return (f == NULL) ? 0 : f->tamanho;
}

int fila_existe(Fila* f, int (*pred)(void*, void*), void* ctx) {
    if (f == NULL) return 0;
    for (NoF* n = f->inicio; n != NULL; n = n->prox)
        if (pred(n->dado, ctx)) return 1;
    return 0;
}

void fila_listar(Fila* f, void (*imprimir)(void*)) {
    if (f == NULL || f->inicio == NULL) {
        printf("A sala de espera esta vazia.\n");
        return;
    }
    printf("--- Sala de Espera (Fila FIFO - Ordem de Chegada) ---\n");
    int pos = 1;
    for (NoF* n = f->inicio; n != NULL; n = n->prox) {
        printf("%d. ", pos++);
        imprimir(n->dado);
    }
}

void fila_destruir(Fila** f) {
    if (f == NULL || *f == NULL) return;
    while ((*f)->inicio != NULL) fila_remover(f);
    free(*f);
    *f = NULL;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "paciente.h"

NoS* paciente_criar_cadastro() {
    NoS* cabeca = (NoS*) malloc(sizeof(NoS));
    if (cabeca == NULL) return NULL;
    cabeca->prox = NULL;             
    return cabeca;
}

int paciente_inserir(NoS* lista, int id, char* nome) {
    if (lista == NULL) return 0;
    if (paciente_buscar(lista, id) != NULL) return 0;  

    NoS* novo = (NoS*) malloc(sizeof(NoS));
    if (novo == NULL) return 0;
    novo->dados.id = id;
    strncpy(novo->dados.nome, nome, sizeof(novo->dados.nome) - 1);
    novo->dados.nome[sizeof(novo->dados.nome) - 1] = '\0';

    novo->prox = lista->prox;       
    lista->prox = novo;
    return 1;
}

Paciente* paciente_buscar(NoS* lista, int id) {
    if (lista == NULL) return NULL;
    for (NoS* n = lista->prox; n != NULL; n = n->prox)
        if (n->dados.id == id) return &n->dados;
    return NULL;
}

int paciente_remover(NoS* lista, int id) {
    if (lista == NULL) return 0;
    NoS* ant = lista;                
    while (ant->prox != NULL && ant->prox->dados.id != id)
        ant = ant->prox;
    if (ant->prox == NULL) return 0;  

    NoS* alvo = ant->prox;
    ant->prox = alvo->prox;           
    free(alvo);
    return 1;
}

void paciente_listar(NoS* lista) {
    if (lista == NULL || lista->prox == NULL) {
        printf("Nenhum paciente cadastrado.\n");
        return;
    }
    printf("--- Pacientes cadastrados ---\n");
    for (NoS* n = lista->prox; n != NULL; n = n->prox)
        printf("ID %d - %s\n", n->dados.id, n->dados.nome);
}

void paciente_destruir_cadastro(NoS** lista) {
    if (lista == NULL || *lista == NULL) return;
    NoS* n = *lista;                  
    while (n != NULL) {
        NoS* prox = n->prox;
        free(n);
        n = prox;
    }
    *lista = NULL;
}

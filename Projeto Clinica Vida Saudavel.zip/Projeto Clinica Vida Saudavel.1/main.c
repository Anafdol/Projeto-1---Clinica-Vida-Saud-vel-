#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "atendimento.h"
#include "paciente.h"
#include "medico.h"
#include "fila.h"
#include "pilha.h"

void exibir_menu() {
    printf("\n=== CLINICA VIDA SAUDAVEL ===\n");
    printf("1. Cadastrar paciente\n");
    printf("2. Listar pacientes\n");
    printf("3. Inserir medico na escala medica\n");
    printf("4. Listar escala medica\n");
    printf("5. Avancar escala medica\n");
    printf("6. Adicionar paciente na sala de espera\n");
    printf("7. Realizar atendimento\n");
    printf("8. Desfazer ultimo atendimento \n");
    printf("9. Remover paciente do cadastro\n");
    printf("10. Remover medico atual da escala\n");
    printf("11. Buscar paciente por ID\n");
    printf("12. Listar sala de espera\n");
    printf("13. Listar historico de atendimentos\n");
    printf("0. Sair\n");
    printf("Escolha uma opcao: ");
}


int ler_int() {
    int valor, c;
    while (scanf("%d", &valor) != 1) {
        if (feof(stdin)) return 0;                       
        while ((c = getchar()) != '\n' && c != EOF) {}   
        printf("Entrada invalida. Digite um numero: ");
    }
    while ((c = getchar()) != '\n' && c != EOF) {}      
    return valor;
}

static void limpar_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
}

static void pausar_e_limpar() {
    printf("\nPressione [ENTER] para voltar ao menu...");
    getchar();
    system("cls");
}


static int eh_mesmo_paciente(void* dado, void* ctx) {
    return dado == ctx;
}
static int atendimento_do_paciente(void* dado, void* ctx) {
    return ((Atendimento*) dado)->paciente == (Paciente*) ctx;
}


static void imprimir_paciente_fila(void* dado) {
    Paciente* p = (Paciente*) dado;
    printf("ID %d - %s\n", p->id, p->nome);
}

static void imprimir_atendimento_pilha(void* dado) {
    Atendimento* a = (Atendimento*) dado;
    printf("Paciente: %s (ID %d) | Medico: %s (%s)\n",
           a->paciente->nome, a->paciente->id,
           a->medico.nome, a->medico.especialidade);
}

int main() {

    NoS* paciente = paciente_criar_cadastro();
    Escala* escala_medica = medico_criar_escala();
    Fila* sala_de_espera = fila_criar();
    Pilha* historico_atendimento = pilha_criar();

    int opcao, id;
    char nome[50], especialidade[50];
    Paciente* pac_atual;
    Medico* med_atual;
    Atendimento* at_atual;

    system("cls");

    do {
        exibir_menu();
        opcao = ler_int();

        switch(opcao) {
            case 1:
                printf("ID do Paciente: ");
                id = ler_int();
                printf("Nome do Paciente: ");
                scanf(" %49[^\n]", nome);
                limpar_buffer();

                if (paciente_inserir(paciente, id, nome))
                    printf("Registo de paciente efetuado com sucesso!\n");
                else
                    printf("Erro: ja existe um paciente com esse ID.\n");
                break;

            case 2:
                paciente_listar(paciente);
                break;

            case 3:
                printf("ID do Medico: ");
                id = ler_int();
                printf("Nome do Medico: ");
                scanf(" %49[^\n]", nome);
                limpar_buffer();
                printf("Especialidade: ");
                scanf(" %49[^\n]", especialidade);
                limpar_buffer();

                medico_inserir(escala_medica, id, nome, especialidade);
                printf("Medico adicionado na escala medica!\n");
                break;

            case 4:
                medico_listar(escala_medica);
                break;

            case 5:
                if (medico_get_atual(escala_medica) == NULL) {
                    printf("Nenhum medico na escala medica.\n");
                } else {
                    medico_avancar(escala_medica);
                    printf("A escala medica avancou para o proximo plantonista.\n");
                }
                break;

            case 6:
                printf("Digite o ID do paciente que chegou: ");
                id = ler_int();

                pac_atual = paciente_buscar(paciente, id);

                if (pac_atual == NULL) {
                    printf("Erro: Paciente nao encontrado no sistema.\n");
                } else if (fila_existe(sala_de_espera, eh_mesmo_paciente, pac_atual)) {
                    printf("Erro: o paciente %s ja esta na sala de espera.\n", pac_atual->nome);
                } else {
                    fila_adicionar(&sala_de_espera, pac_atual);
                    printf("O paciente %s entrou na sala de espera!\n", pac_atual->nome);
                }
                break;

            case 7:
                if (fila_tamanho(sala_de_espera) == 0) {
                    printf("A sala de espera esta vazia.\n");
                } else if (medico_get_atual(escala_medica) == NULL) {
                    printf("Nenhum medico na escala medica.\n");
                } else {
                    pac_atual = (Paciente*) fila_topo(sala_de_espera);
                    fila_remover(&sala_de_espera);

                    med_atual = medico_get_atual(escala_medica);

                    at_atual = (Atendimento*) malloc(sizeof(Atendimento));
                    at_atual->paciente = pac_atual;
                    at_atual->medico = *med_atual;      /* copia do medico */

                    pilha_adicionar(&historico_atendimento, at_atual);

                    printf("Paciente %s foi atendido por %s.\n", pac_atual->nome, med_atual->nome);

                    medico_avancar(escala_medica);
                }
                break;

            case 8:
                if (pilha_tamanho(historico_atendimento) == 0) {
                    printf("O historico de atendimento esta vazio.\n");
                } else {
                    at_atual = (Atendimento*) pilha_topo(historico_atendimento);
                    pilha_remover(&historico_atendimento);
                    fila_adicionar(&sala_de_espera, at_atual->paciente);
                    printf("Atendimento desfeito! O paciente %s voltou para a sala de espera.\n", at_atual->paciente->nome);
                    free(at_atual);
                }
                break;

            case 9:
                printf("ID do paciente a remover: ");
                id = ler_int();
                pac_atual = paciente_buscar(paciente, id);

                if (pac_atual == NULL) {
                    printf("Paciente nao encontrado.\n");
                } else if (fila_existe(sala_de_espera, eh_mesmo_paciente, pac_atual)) {
                    printf("Nao e possivel remover: o paciente esta na sala de espera.\n");
                } else if (pilha_existe(historico_atendimento, atendimento_do_paciente, pac_atual)) {
                    printf("Nao e possivel remover: o paciente consta no historico de atendimentos.\n");
                } else {
                    paciente_remover(paciente, id);
                    printf("Paciente removido.\n");
                }
                break;

            case 10:
                if (medico_get_atual(escala_medica) == NULL) {
                    printf("Nenhum medico na escala medica.\n");
                } else {
                    medico_remover_atual(escala_medica);
                    printf("Medico atual removido da escala.\n");
                }
                break;

            case 11:
                printf("ID do paciente a buscar: ");
                id = ler_int();
                pac_atual = paciente_buscar(paciente, id);
                if (pac_atual != NULL) {
                    printf("Paciente encontrado: ID %d - %s\n", pac_atual->id, pac_atual->nome);
                } else {
                    printf("Paciente com ID %d nao encontrado.\n", id);
                }
                break;

            case 12:
                fila_listar(sala_de_espera, imprimir_paciente_fila);
                break;

            case 13:
                pilha_listar(historico_atendimento, imprimir_atendimento_pilha);
                break;

            case 0:
                printf("A encerrar o sistema...\n");
                break;

            default:
                printf("Opcao invalida. Tente novamente.\n");
        }

        if (opcao != 0) {
            pausar_e_limpar();
        }

    } while (opcao != 0);

    paciente_destruir_cadastro(&paciente);
    medico_destruir_escala(&escala_medica);
    fila_destruir(&sala_de_espera);

    while (pilha_tamanho(historico_atendimento) > 0) {
        at_atual = (Atendimento*) pilha_topo(historico_atendimento);
        pilha_remover(&historico_atendimento);
        free(at_atual);
    }
    pilha_destruir(&historico_atendimento);

    return 0;
}

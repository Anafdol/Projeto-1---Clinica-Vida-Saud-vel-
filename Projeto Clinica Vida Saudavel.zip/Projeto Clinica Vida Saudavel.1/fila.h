#ifndef FILA_H
#define FILA_H

typedef struct Fila Fila;

Fila* fila_criar();
void  fila_adicionar(Fila** f, void* dado);      
void* fila_topo(Fila* f);                        
void  fila_remover(Fila** f);                    
int   fila_tamanho(Fila* f);
int   fila_existe(Fila* f, int (*pred)(void*, void*), void* ctx);
void  fila_listar(Fila* f, void (*imprimir)(void*));
void  fila_destruir(Fila** f);                   

#endif

#ifndef MEDICO_H
#define MEDICO_H

typedef struct {
    int id;
    char nome[50];
    char especialidade[50];
} Medico;

typedef struct Escala Escala;

Escala* medico_criar_escala();
void    medico_inserir(Escala* e, int id, char* nome, char* especialidade);
void    medico_listar(Escala* e);           
void    medico_avancar(Escala* e);          
Medico* medico_get_atual(Escala* e);        
void    medico_remover_atual(Escala* e);     
void    medico_destruir_escala(Escala** e);

#endif
